# [HumHub](https://github.com/humhub/humhub) Themes FlatHub
FlatHub - Light flat theme for **HumHub 1.3.6** and and higher.

![FlatHub](https://raw.githubusercontent.com/sashatravkina/humhub1.3.6-themes-flathub/master/screenshot/thumb_flathub.jpg)

## Features
- Light flat design
- Style switcher
- Sidebar left position
- Custom main menu
- Login page animated background
- Grid images
- More changes

## Install
- Extract archive and rename to FlatHub.
- Put this folder in: yousite.com/themes

## Donate
If you want help author to buy pizzas.

[PayPal](https://paypal.me/forsashatravkina)

Webmoney
- Z379197233784
- E703204503713
- R122595933015

YandexMoney
- 41001757647345

## Author
Alexandra Travkina - [fixel.ru](https://fixel.ru)
