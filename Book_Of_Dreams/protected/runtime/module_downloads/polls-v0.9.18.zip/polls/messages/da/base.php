<?php

return [
    'Allows to start polls.' => '',
    'At least one answer is required' => '',
    'Cancel' => 'Afbryd',
    'Polls' => 'Afstemninger',
    'Save' => 'Gem',
];
