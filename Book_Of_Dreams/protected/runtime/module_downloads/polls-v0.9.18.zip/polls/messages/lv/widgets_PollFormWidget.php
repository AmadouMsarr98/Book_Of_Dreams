<?php
return array (
  'Ask' => 'Pavaicā',
);
