<?php
return array (
  'User who vote this' => 'Utente che ha votato',
);
