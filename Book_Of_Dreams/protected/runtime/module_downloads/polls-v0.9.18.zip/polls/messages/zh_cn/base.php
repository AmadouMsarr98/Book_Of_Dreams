<?php

return [
    'At least one answer is required' => '',
    'Allows to start polls.' => '允许开始投票',
    'Cancel' => '取消',
    'Polls' => '投票',
    'Save' => '保存',
];
