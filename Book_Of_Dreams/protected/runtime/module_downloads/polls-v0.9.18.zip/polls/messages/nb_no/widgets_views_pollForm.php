<?php
return array (
  'Add answer...' => 'Legg til svar...',
  'Anonymous Votes?' => 'Anonyme svar?',
  'Ask something...' => 'Still et spørsmål...',
  'Display answers in random order?' => 'Vis svar i tilfeldig rekkefølge?',
  'Edit answer (empty answers will be removed)...' => 'Rediger svar (tomme svar vil fjernes)...',
  'Edit your poll question...' => 'Rediger spørsmålet...',
  'Hide results until poll is closed?' => 'Ikke vis resultat før meningsmålingen er avsluttet?',
);
