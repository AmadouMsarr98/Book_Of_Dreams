<?php
return array (
  'Access denied!' => 'Ingen tilgang!',
  'Anonymous poll!' => 'Anonym meningsmåling',
  'Could not load poll!' => 'Kunne ikke laste meningsmåling!',
  'Invalid answer!' => 'Ugyldig svar!',
  'Users voted for: <strong>{answer}</strong>' => 'Brukerne stemte for: <strong>{answer}</strong>',
  'Voting for multiple answers is disabled!' => 'Stemming på flere alternativer er ikke tillatt!',
  'You have insufficient permissions to perform that operation!' => 'Du har ikke tilgang til å utføre handlingen!',
);
