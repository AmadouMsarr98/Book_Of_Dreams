<?php
return array (
  '{userName} created a new {question}.' => '{userName} heeft een nieuwe {question} aangemaakt.',
);
