<?php
return array (
  '{userName} created a new poll and assigned you.' => '{userName} sukurė naują apklausą ir priskyrė Jus.',
);
