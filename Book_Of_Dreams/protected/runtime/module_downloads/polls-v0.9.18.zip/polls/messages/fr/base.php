<?php
return array (
  'Allows to start polls.' => 'Ce module permet de créer des sondages.',
  'At least one answer is required' => 'Au moins une réponse est obligatoire',
  'Cancel' => 'Annuler',
  'Polls' => 'Sondages',
  'Save' => 'Enregistrer',
);
