<?php
return array (
  'Add answer...' => 'Lisää vastaus...',
  'Anonymous Votes?' => 'Haluatko että vastaukset ovat anonymeja?',
  'Ask something...' => 'Kysy jotain...',
  'Display answers in random order?' => 'Näytä vastaukset satunnaisessa järjestyksessä',
  'Edit answer (empty answers will be removed)...' => 'Muokkaa vastausta (tyhäjä vastaus voidaan poistaa)...',
  'Edit your poll question...' => 'Muokkaa sinun kyselyn kysymyksiä...',
  'Hide results until poll is closed?' => 'Piilota tulokset, kunnes kysely on suljettu?',
);
