<?php
return array (
  '{userName} created a new {question}.' => '{userName} skapade en ny {question}.',
);
