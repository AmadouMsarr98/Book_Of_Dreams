<?php
return array (
  'Ask' => 'Fråga',
);
