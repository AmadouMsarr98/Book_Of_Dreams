<?php
return array (
  'User who vote this' => 'Nutzer, die hierfür abstimmten',
);
