<?php
return array (
  '<strong>Note:</strong> The result is hidden until the poll is closed by a moderator.' => '<strong> Napomena: </strong> rezultat je skriven dok moderator ne zatvori anketu.',
  'Anonymous' => 'Anonimno',
  'Closed' => 'Zatvoreno',
  'Complete Poll' => 'Cijela anketa',
  'Reopen Poll' => 'Re-otvori anketu',
  'Reset my vote' => 'Resetiraj moj glas',
  'Vote' => 'Glasaj',
  'and {count} more vote for this.' => 'i {count} više glasova za ovo.',
  'votes' => 'glasova',
);
