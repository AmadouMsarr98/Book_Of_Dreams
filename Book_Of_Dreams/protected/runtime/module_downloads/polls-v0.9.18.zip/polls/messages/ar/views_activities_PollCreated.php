<?php
return array (
  '{userName} created a new {question}.' => '',
);
