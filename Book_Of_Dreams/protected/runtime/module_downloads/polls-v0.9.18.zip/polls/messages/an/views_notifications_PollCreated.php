<?php
return array (
  '{userName} created a new poll and assigned you.' => '{userName} ha creyau una nueva enqüesta y te l\'ha asignau.',
);
