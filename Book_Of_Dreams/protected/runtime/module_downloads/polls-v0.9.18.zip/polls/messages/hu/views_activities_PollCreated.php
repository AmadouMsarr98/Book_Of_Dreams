<?php
return array (
  '{userName} created a new {question}.' => '{userName} létrehozott egy új {question}.',
);
