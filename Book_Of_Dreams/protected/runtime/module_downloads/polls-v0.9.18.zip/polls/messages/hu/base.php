<?php

return [
    'At least one answer is required' => '',
    'Allows to start polls.' => 'Engedélyezi szavazás indítását.',
    'Cancel' => 'Mégsem',
    'Polls' => 'Szavazás',
    'Save' => 'Mentés',
];
