<?php
return array (
  'Answers' => 'Respostas',
  'Multiple answers per user' => 'Múltiplas respostas por usuário',
  'Please specify at least {min} answers!' => 'Especifique pelo menos {min} respostas!',
  'Question' => 'Pergunta',
);
