<?php
return array (
  '<strong>Note:</strong> The result is hidden until the poll is closed by a moderator.' => '<strong>Uwaga:</strong> Wynik głosowania jest ukryty dopóki ankieta nie zostanie zamknięta przez moderatora.',
  'Anonymous' => 'Anonimowo',
  'Closed' => 'Zamknięte',
  'Complete Poll' => 'Zakończ głosowanie',
  'Reopen Poll' => 'Wznów głosowanie',
  'Reset my vote' => 'Resetuj mój głos',
  'Vote' => 'Głos',
  'and {count} more vote for this.' => 'i {count} więcej głosów.',
  'votes' => 'głosy',
);
