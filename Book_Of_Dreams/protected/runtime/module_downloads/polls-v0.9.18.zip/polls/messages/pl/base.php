<?php
return array (
  'Allows to start polls.' => 'Pozwala dodawać głosowania.',
  'At least one answer is required' => 'Przynajmniej jedna odpowiedź jest wymagana',
  'Cancel' => 'Anuluj',
  'Polls' => 'Głosowania',
  'Save' => 'Zapisz',
);
