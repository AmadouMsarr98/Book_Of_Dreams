<?php
return array (
  'User who vote this' => 'Użytkownicy którzy głosowali na to ',
);
