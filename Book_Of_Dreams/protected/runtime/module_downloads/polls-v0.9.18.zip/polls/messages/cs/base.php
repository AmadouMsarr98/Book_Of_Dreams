<?php

return [
    'At least one answer is required' => '',
    'Allows to start polls.' => 'Povolení vytváření anket',
    'Cancel' => 'Zrušit',
    'Polls' => 'Ankety',
    'Save' => 'Uložit',
];
