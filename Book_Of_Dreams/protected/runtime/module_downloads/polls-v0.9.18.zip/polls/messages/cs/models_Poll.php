<?php
return array (
  'Answers' => '"Odpovědi"',
  'Multiple answers per user' => 'Více odpovědí na jednoho uživatele',
  'Please specify at least {min} answers!' => 'Minimální počet možných odpovědí je {min}.',
  'Question' => '"Otázka"',
);
