Changelog
=========
0.9.18 - June 17, 2019
- Enh: Updated translations
- Enh: Updated docs


0.9.17 - November 07, 2018
-----------------------
- Fix: Empty answer submittion not intercepted


0.9.16 - July 25, 2018
-----------------------
- Fix: #49 Added stream topic filter for HumHub >= v.1.3


0.9.15 - July 25, 2018
-----------------------
- Fix: Closing polls removing answers


0.9.14 - July 13, 2018
-----------------------
- Fix: #39 Saving poll after removing all old answers failed


0.9.13 - July 2, 2018
-----------------------
- Fix: PHP 7.2 compatibility issues


0.9.12 - 17 April, 2018
------------------------
- Enh: Updated translations


0.9.11 - 12 April, 2018
------------------------
- Enh: Added `Hide results until poll is closed?` option.



