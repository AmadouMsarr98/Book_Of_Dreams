# Wiki

Collect and share information with your very own Wiki. 

## Overview

- Create individual Wikis for every Space and Profile
- Edit them with ease using our WYSIWYG editor
- Link between pages and even individual paragraphs
- Keep track on changes with a build in page history 
- Include pictures and format them on-the-fly
- Move content between Spaces