<?php
return array (
  'Wiki page' => 'Page Wiki',
);
