<?php

return [
    '<strong>Create</strong> new page' => '<strong>Yeni</strong> sayfa oluştur',
    '<strong>Edit</strong> page' => '<strong>Sayfayı</strong> Düzenle',
    'New page title' => 'Yeni Sayfa Başlığı',
];
