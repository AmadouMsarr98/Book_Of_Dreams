<?php
return array (
  'Open wiki page...' => 'Wiki sayfası açık...',
);
