<?php

return [
    '<strong>Create</strong> new page' => 'Neue Seite <strong>erstellen</strong>',
    '<strong>Edit</strong> page' => 'Seite <strong>bearbeiten</strong> ',
    'New page title' => 'Neuer Seitentitel',
];
