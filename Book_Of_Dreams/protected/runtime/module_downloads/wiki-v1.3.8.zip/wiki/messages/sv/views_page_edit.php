<?php

return [
    '<strong>Create</strong> new page' => '<strong>Skapa</strong> ny sida',
    '<strong>Edit</strong> page' => '<strong>Ändra</strong> sida',
    'New page title' => 'Ny sidrubrik',
];
