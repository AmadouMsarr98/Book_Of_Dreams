<?php
return array (
  'Wiki page' => 'Wikisida',
);
