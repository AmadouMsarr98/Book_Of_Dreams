<?php
return array (
  '<strong>Create</strong> new page' => '<strong>Maak</strong> nieuwe pagina',
  '<strong>Edit</strong> page' => '<strong>Bewerk</strong> pagina',
  'New page title' => 'Nieuwe paginakop',
);
