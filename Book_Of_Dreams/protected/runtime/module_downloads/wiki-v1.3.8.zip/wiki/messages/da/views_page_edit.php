<?php

return [
    '<strong>Create</strong> new page' => '<strong>Opret</strong> ny side',
    '<strong>Edit</strong> page' => '<strong>Rediger</strong> side',
    'New page title' => 'Ny side titel',
];
