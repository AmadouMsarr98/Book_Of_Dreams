<?php

return [
    '<strong>Create</strong> new page' => '<strong>ایجاد</strong> صفحه‌ی جدید',
    '<strong>Edit</strong> page' => '<strong>ویرایش</strong> صفحه',
    'New page title' => 'عنوان صفحه‌ی جدید',
];
