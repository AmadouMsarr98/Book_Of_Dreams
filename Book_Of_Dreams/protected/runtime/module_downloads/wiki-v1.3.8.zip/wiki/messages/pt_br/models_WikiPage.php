<?php
return array (
  'Wiki page' => 'Página Wiki',
);
