<?php
return array (
  'Open wiki page...' => 'Avaa sivu',
);
