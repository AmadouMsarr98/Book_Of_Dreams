<?php

return [
    '<strong>Create</strong> new page' => '<strong>Sukurti</strong> naują puslapį',
    '<strong>Edit</strong> page' => '<strong>Taisyti</strong> puslapį',
    'New page title' => 'Naujo puslapio pavadinimas',
];
