<?php

return [
    '<strong>Create</strong> new page' => '',
    'New page title' => '',
    '<strong>Edit</strong> page' => '<strong>Edita</strong> la pàgina',
];
