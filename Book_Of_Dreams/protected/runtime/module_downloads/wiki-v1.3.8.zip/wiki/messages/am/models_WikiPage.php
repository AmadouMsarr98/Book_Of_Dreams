<?php

return [
    'Wiki page' => '',
];
