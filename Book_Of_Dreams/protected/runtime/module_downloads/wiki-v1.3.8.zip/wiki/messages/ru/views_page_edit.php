<?php

return [
    '<strong>Create</strong> new page' => '<strong>Создать</strong> новую страницу',
    '<strong>Edit</strong> page' => '<strong>Редактировать</strong> страницу',
    'New page title' => 'Название новой страницы',
];
