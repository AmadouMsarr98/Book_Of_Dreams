<?php
return array (
  'Open wiki page...' => 'Otvori wiki stranicu...',
);
