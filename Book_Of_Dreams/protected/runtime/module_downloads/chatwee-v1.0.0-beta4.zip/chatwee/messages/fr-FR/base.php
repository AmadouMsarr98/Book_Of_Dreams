<?php
    return [
        'ChatWee Settings' => 'ChatWee Paramètres',
        'ChatWee Widget URL:' => 'ChatWee URL du Widget:',
        '<strong>ChatWee</strong> module configuration' => '<strong>ChatWee</ strong> Configuration du module',
        'Save' => 'Sauver',
    ];
