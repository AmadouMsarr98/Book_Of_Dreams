<?php
    return [
        'ChatWee Settings' => 'ChatWee Ayarlar',
        'ChatWee Widget URL:' => 'ChatWee Widget URL:',
        '<strong>ChatWee</strong> module configuration' => '<strong>ChatWee</strong> modül yapılandırması',
        'Save' => 'Kaydet',
    ];
