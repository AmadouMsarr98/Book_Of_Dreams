<?php
    return [
        'ChatWee Settings' => 'ChatWee 設置',
        'ChatWee Widget URL:' => 'ChatWee Widget URL:',
        '<strong>ChatWee</strong> module configuration' => '<strong> ChatWee </ strong>模塊配置',
        'Save' => '保存',
    ];
