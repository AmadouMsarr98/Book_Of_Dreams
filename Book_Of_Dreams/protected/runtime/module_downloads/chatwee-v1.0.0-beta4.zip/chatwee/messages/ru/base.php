<?php
    return [
        'ChatWee Settings' => 'Настройки ChatWee',
        'ChatWee Widget URL:' => 'URL виджета ChatWee:',
        '<strong>ChatWee</strong> module configuration' => 'Конфигурация модуля <strong>ChatWee</strong>',
        'Save' => 'Сохранить',
    ];
