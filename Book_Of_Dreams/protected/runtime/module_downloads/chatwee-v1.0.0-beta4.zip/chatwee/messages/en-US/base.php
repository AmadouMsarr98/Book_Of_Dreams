<?php
    return [
        'ChatWee Settings' => 'ChatWee Settings',
        'ChatWee Widget URL:' => 'ChatWee Widget URL:',
        '<strong>ChatWee</strong> module configuration' => '<strong>ChatWee</strong> module configuration',
        'Save' => 'Save',
    ];
