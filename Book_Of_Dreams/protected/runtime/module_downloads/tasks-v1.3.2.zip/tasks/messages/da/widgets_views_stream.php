<?php
return array (
  'Back to stream' => '@@Tilbage til stream@@',
  'No tasks found which matches your current filter(s)!' => '@@Ingen opgaver fundet som matcher dit nuværende filter!@@',
  '<b>There are no tasks yet!</b>' => '<b>Der er ingen opgaver endnu!</b>',
  '<b>There are no tasks yet!</b><br>Be the first and create one...' => '<b>Der er ingen opgaver endnu!</b><br>Vær den første og opret en...',
  'Assigned to me' => 'Tildelt til mig',
  'Created by me' => 'Oprettet af mig',
  'Creation time' => 'Oprettelses tidspunkt',
  'Filter' => 'Filter',
  'Last update' => 'Seneste opdatering',
  'Nobody assigned' => 'Ingen tilføjet',
  'Sorting' => 'Sortering',
  'State is finished' => 'Status er færdig',
  'State is open' => 'Status er åben',
);
