<?php
return array (
  '{userName} assigned you to the task {task}.' => '{userName} tilføjede dig til opgaven {task}.',
);
