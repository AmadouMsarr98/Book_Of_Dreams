<?php
return array (
  '<strong>Confirm</strong> deleting' => '<strong>Bekræft</strong> sletning',
  'Add Task' => 'Tilføj opgave',
  'Cancel' => 'Afbryd',
  'Delete' => 'Slet',
  'Do you really want to delete this task?' => 'Vil du virkelig slette denne opgave?',
  'No open tasks...' => 'Ingen åbne opgaver...',
  'completed tasks' => 'udførte opgaver',
);
