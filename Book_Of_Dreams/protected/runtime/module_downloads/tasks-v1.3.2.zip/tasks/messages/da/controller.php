<?php
return array (
  'Already requested' => '',
  'Request sent' => '',
  'You have insufficient permissions to perform that operation!' => 'Du har utilstrækkelig adgang til at udføre denne opgave!',
);
