<?php
return array (
  'Completed' => '',
  'Title' => 'عنوان',
);
