<?php
return array (
  '{userName} finished task {task}.' => '{userName} {task} را به پایان رساند.',
);
