<?php
return array (
  'End Date' => 'تاریخ پایان',
  'End Time' => 'پایان زمان',
  'End time must be after start time!' => 'تاریخ پایان باید پس از تاریخ آغاز باشد!',
  'Public' => 'عمومی',
  'Start Date' => 'تاریخ شروع',
  'Start Time' => 'آغاز زمان',
  'Time Zone' => '',
);
