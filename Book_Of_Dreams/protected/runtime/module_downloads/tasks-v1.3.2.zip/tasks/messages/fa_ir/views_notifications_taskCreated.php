<?php
return array (
  '{userName} created a new task {task}.' => '{userName} کار جدید {task} را ایجاد کرد.',
);
