<?php
return array (
  '{userName} assigned you as responsible person in task {task} from space {spaceName}.' => '{userName} antoi sinulle vastuuhenkilön tehtävän tehtävään {task} sivulla {spaceName}.',
);
