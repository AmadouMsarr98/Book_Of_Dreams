<?php
return array (
  'End Date' => 'Päättymispäivä',
  'End Time' => 'Päättymisaika',
  'End time must be after start time!' => 'Päättymisaika on oltava alkamisajan jälkeen!',
  'Public' => 'Julkinen',
  'Start Date' => 'Aloituspäivä',
  'Start Time' => 'Aloitusaika',
  'Time Zone' => 'Aikavyöhyke',
);
