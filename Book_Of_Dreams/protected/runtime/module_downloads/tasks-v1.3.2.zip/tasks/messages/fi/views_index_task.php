<?php
return array (
  'Task Users have been notified' => 'Tehtävien käyttäjiä on informoitu',
);
