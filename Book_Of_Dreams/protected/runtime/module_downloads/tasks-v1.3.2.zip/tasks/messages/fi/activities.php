<?php
return array (
  '{userName} completed task {task}.' => '{userName} suoritti tehtävän {task}.',
  '{userName} reset task {task}.' => '{userName} palautti tehtävän {task}.',
  '{userName} reviewed task {task}.' => '{userName} tarkasteli tehtävää {task}.',
  '{userName} works on task {task}.' => '{userName} työstää tehtävää {task}.',
);
