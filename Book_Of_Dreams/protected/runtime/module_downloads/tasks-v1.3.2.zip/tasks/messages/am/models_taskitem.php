<?php
return array (
  'Completed' => '',
  'Title' => 'ርዕስ',
);
