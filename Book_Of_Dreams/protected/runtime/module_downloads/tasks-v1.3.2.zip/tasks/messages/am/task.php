<?php

return [
    'Allows the user to create, delete and edit tasks and lists and also sort tasks and lists' => '',
    'Allows the user to process unassigned tasks' => '',
    'Manage tasks' => '',
    'Process unassigned tasks' => '',
];
