<?php
return array (
  'Created by me' => 'በእኔ የተፈጠረ',
  'End date' => '',
  'Filter status' => '',
  'Filter tasks' => '',
  'I\'m assigned' => '',
  'I\'m responsible' => '',
  'Overdue' => '',
  'Spaces' => 'ምህዳሮች',
  'Start date' => '',
  'Status' => '',
  'Title' => 'ርዕስ',
);
