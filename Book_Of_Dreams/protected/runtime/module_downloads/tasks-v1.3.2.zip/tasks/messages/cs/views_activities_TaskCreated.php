<?php
return array (
  '{userName} created task {task}.' => '{userName} vytvořil(a) úkol {task}.',
);
