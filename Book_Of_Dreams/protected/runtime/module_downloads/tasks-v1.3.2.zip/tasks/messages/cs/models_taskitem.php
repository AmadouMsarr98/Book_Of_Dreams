<?php
return array (
  'Completed' => '',
  'Title' => 'Název',
);
