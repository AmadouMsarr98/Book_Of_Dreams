<?php
return array (
  'End Date' => 'Datum konce',
  'End Time' => 'Čas konce',
  'End time must be after start time!' => 'Datum konce události musí následovat po začátku!',
  'Public' => 'Veřejné',
  'Start Date' => 'Datum začátku',
  'Start Time' => 'Čas začátku',
  'Time Zone' => '',
);
