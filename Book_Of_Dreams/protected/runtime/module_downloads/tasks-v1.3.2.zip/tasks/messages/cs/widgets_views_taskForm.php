<?php
return array (
  'Assign users to this task' => 'Přiřadit úkol uživateli (nepovinné)',
  'Deadline for this task?' => 'Termín dokončení úkolu?',
  'Preassign user(s) for this task.' => 'Přidělení úkolu uživateli/uživatelům.',
  'What to do?' => 'Co je potřeba udělat?',
);
