<?php
return array (
  'Created by me' => 'Creada por mí',
  'End date' => '',
  'Filter status' => '',
  'Filter tasks' => '',
  'I\'m assigned' => '',
  'I\'m responsible' => '',
  'Overdue' => '',
  'Spaces' => 'Espacios',
  'Start date' => '',
  'Status' => 'Estado',
  'Title' => 'Título',
);
