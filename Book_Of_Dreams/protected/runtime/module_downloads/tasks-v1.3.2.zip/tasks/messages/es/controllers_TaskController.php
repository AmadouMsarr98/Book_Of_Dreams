<?php
return array (
  'Could not access task!' => '¡No se pudo acceder a la tarea!',
);
