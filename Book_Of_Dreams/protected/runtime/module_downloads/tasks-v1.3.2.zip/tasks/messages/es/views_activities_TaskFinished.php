<?php
return array (
  '{userName} finished task {task}.' => '{userName} completó la tarea {task}.',
);
