<?php
return array (
  '{userName} created a new task {task}.' => '{userName} creó una nueva tarea {task}.',
);
