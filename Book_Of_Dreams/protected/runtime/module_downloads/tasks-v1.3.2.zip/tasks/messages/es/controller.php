<?php
return array (
  'Already requested' => '',
  'Request sent' => '',
  'You have insufficient permissions to perform that operation!' => '¡No tienes suficientes permisos para hacer esa operación!',
);
