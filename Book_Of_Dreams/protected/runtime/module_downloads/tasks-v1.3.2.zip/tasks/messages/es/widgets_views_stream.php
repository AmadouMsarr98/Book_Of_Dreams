<?php
return array (
  'Back to stream' => '@@Volver a Actividad@@',
  'No tasks found which matches your current filter(s)!' => '@@¡No se han encontrado tareas que coincidan con tu filtro!@@',
  '<b>There are no tasks yet!</b>' => '<b>¡No hay tareas todavía!</b>',
  '<b>There are no tasks yet!</b><br>Be the first and create one...' => '<b>¡No hay tareas todavía!</b><br>Se el primero en crear una...',
  'Assigned to me' => 'Asignadas a mí',
  'Created by me' => 'Creada por mí',
  'Creation time' => 'Fecha de creación',
  'Filter' => 'Filtro',
  'Last update' => 'Última actualización',
  'Nobody assigned' => 'Nadie asignado',
  'Sorting' => 'Ordenación',
  'State is finished' => 'El estado es completada',
  'State is open' => 'El estado es abierta',
);
