<?php
return array (
  '<b>There are no tasks yet!</b>' => '',
  '<b>There are no tasks yet!</b><br>Be the first and create one...' => '',
  'Assigned to me' => '',
  'Back to stream' => '@@@@',
  'Created by me' => 'Creyau per yo',
  'Creation time' => 'Hora de creyación',
  'Filter' => 'Filtrar',
  'Last update' => 'Zaguera actualización',
  'No tasks found which matches your current filter(s)!' => '@@@@',
  'Nobody assigned' => '',
  'Sorting' => 'Ordenación',
  'State is finished' => '',
  'State is open' => '',
);
