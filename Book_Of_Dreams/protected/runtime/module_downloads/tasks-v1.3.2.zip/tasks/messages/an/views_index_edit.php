<?php

return [
    '<strong>Confirm</strong> task deletion' => '',
    '<strong>Create</strong> new task' => '',
    '<strong>Edit</strong> task' => '',
    'Add checkpoint...' => '',
    'Add reminder' => '',
    'Add responsible users' => '',
    'Assign users' => '',
    'Assignment' => '',
    'Basic' => '',
    'Checklist' => '',
    'Do you really want to delete this task?' => '',
    'Edit item (empty field will be removed)...' => '',
    'Files' => '',
    'Leave empty to let anyone work on this task.' => '',
    'Scheduling' => '',
    'Title and Color' => '',
    'Title of your task' => '',
];
