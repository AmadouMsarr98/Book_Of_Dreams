<?php
return array (
  'Drag list' => 'Faire glisser une liste',
);
