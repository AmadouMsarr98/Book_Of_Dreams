<?php
return array (
  'Your Reminder for task {task}' => 'Votre rappel pour la tâche {task}',
);
