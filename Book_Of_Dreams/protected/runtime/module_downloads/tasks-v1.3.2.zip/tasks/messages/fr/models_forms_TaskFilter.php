<?php
return array (
  'Created by me' => 'Créé par moi',
  'End date' => 'Date de fin',
  'Filter status' => 'Filtrer par statut',
  'Filter tasks' => 'Filtrer les tâches',
  'I\'m assigned' => 'Je suis assigné',
  'I\'m responsible' => 'Je suis responsable',
  'Overdue' => 'Échue',
  'Spaces' => 'Espaces',
  'Start date' => 'Date de début',
  'Status' => 'Statut',
  'Title' => 'Titre',
);
