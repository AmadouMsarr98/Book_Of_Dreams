<?php
return array (
  '{userName} completed task {task}.' => '{userName} a complété la tâche {task}.',
  '{userName} reset task {task}.' => '{userName} a redémarré la tâche {task}.',
  '{userName} reviewed task {task}.' => '{userName} a examiné la tâche {task}.',
  '{userName} works on task {task}.' => '{userName} travaille sur la tâche {task}.',
);
