<?php
return array (
  'Click, to finish this task' => 'Terminer cette tâche',
  'This task is already done. Click to reopen.' => 'Cette tâche est déjà terminée. Cliquer pour la ré-ouvrir.',
);
