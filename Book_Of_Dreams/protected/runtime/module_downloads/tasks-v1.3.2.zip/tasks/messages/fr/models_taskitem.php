<?php
return array (
  'Completed' => 'Terminé',
  'Title' => 'Titre',
);
