<?php
return array (
  '<strong>Confirm</strong> deleting' => '<strong>Confirmer</strong> la suppression',
  'Add Task' => 'Ajouter une tâche',
  'Cancel' => 'Annuler',
  'Delete' => 'Effacer',
  'Do you really want to delete this task?' => 'Vouhaitez-vous vraiment supprimer cette tâche ?',
  'No open tasks...' => 'Pas de tâche ouverte...',
  'completed tasks' => 'tâche(s) terminée(s)',
);
