<?php
return array (
  '1 Day before' => '',
  '1 Month before' => '',
  '1 Week before' => '',
  '2 Days before' => '',
  '2 Weeks before' => '',
  '3 Weeks before' => '',
  'At least 1 Hour before' => '',
  'At least 2 Hours before' => '',
  'Do not remind' => '',
  'Remind Mode' => '',
  'Task' => 'Zadatak',
);
