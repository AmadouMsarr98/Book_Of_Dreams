<?php
return array (
  'Could not access task!' => 'Nije moguće pristupiti zadatku!',
);
