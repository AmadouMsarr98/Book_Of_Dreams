<?php
return array (
  'Assign users to this task' => 'Dodijeli korisnike ovom zadatku',
  'Deadline for this task?' => 'Krajnji rok za ovaj zadatak?',
  'Preassign user(s) for this task.' => 'Preraspodijelite korisnika(e) za ovaj zadatak.',
  'What to do?' => 'Što treba učiniti?',
);
