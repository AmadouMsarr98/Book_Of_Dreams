<?php
return array (
  'End Date' => 'Datum završetka',
  'End Time' => 'Vrijeme završetka',
  'End time must be after start time!' => 'Vrijeme završetka mora biti nakon vremena početka!',
  'Public' => 'Javno',
  'Start Date' => 'Datum početka',
  'Start Time' => 'Vrijeme početka',
  'Time Zone' => 'Vremenska zona',
);
