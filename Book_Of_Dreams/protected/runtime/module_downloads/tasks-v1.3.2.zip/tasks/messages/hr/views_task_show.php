<?php
return array (
  '<strong>Confirm</strong> deleting' => '<strong>Potvrdi</strong> brisanje',
  'Add Task' => 'Dodaj zadatak',
  'Cancel' => 'Poništi',
  'Delete' => 'Obriši',
  'Do you really want to delete this task?' => 'Želite li stvarno izbrisati taj zadatak?',
  'No open tasks...' => 'Nema otvorenih zadataka...',
  'completed tasks' => 'završeni zadaci',
);
