<?php
return array (
  '<strong>Create</strong> new task' => '<strong>Kreiraj</strong> novi zadatak',
  '<strong>Edit</strong> task' => '<strong>Uredi</strong> zadatak',
  'Assign users' => 'Dodijeli korisnike',
  'Cancel' => 'Poništi',
  'Deadline' => 'Krajnji rok',
  'Save' => 'Spremi',
  'What is to do?' => 'Što treba učiniti?',
);
