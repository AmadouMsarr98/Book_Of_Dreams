<?php
return array (
  '{userName} finished task {task}.' => '{userName} ha finalitzat la tasca {task}.',
);
