<?php
return array (
  'Created by me' => 'Creat per mi',
  'End date' => '',
  'Filter status' => '',
  'Filter tasks' => '',
  'I\'m assigned' => '',
  'I\'m responsible' => '',
  'Overdue' => '',
  'Spaces' => 'Espais',
  'Start date' => '',
  'Status' => 'Estat',
  'Title' => 'Títol',
);
