<?php
return array (
  'Already requested' => 'Wurde bereits angefordert',
  'Request sent' => 'Anfrage gesendet',
  'You have insufficient permissions to perform that operation!' => 'Du hast keine ausreichenden Berechtigungen, um diesen Vorgang auszuführen!',
);
