<?php
return array (
  '{userName} assigned you to the task {task}.' => '{userName} hat Dich der Aufgabe »{task}« zugeordnet.',
);
