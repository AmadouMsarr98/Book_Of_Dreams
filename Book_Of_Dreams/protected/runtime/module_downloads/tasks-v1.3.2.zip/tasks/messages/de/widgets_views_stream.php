<?php
return array (
  '<b>There are no tasks yet!</b>' => '<b>Es existieren noch keine Aufgaben!</b>',
  '<b>There are no tasks yet!</b><br>Be the first and create one...' => '<b>Es gibt noch keine Aufgaben!</b><br>Sei der Erste und erstelle eine....',
  'Assigned to me' => 'Mir zugeordnet',
  'Assignment' => 'Zuweisung',
  'Back to stream' => '@@Zurück zur Übersicht@@',
  'Created by me' => 'Von mir erstellt',
  'Creation time' => 'Erstellungsdatum',
  'Filter' => 'Filter',
  'Last update' => 'Letzte Aktualisierung',
  'No tasks found which matches your current filter(s)!' => '@@Keine Aufgaben zu den gewählten Filtereinstellungen gefunden!@@',
  'Nobody assigned' => 'Niemand zugeordnet',
  'Sorting' => 'Sortierung',
  'State is finished' => 'Status: abgeschlossen',
  'State is open' => 'Status: offen',
);
