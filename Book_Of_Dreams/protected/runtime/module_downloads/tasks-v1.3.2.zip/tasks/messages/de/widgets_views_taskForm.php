<?php
return array (
  'Assign users to this task' => 'Benutzer dieser Aufgabe zuordnen',
  'Deadline for this task?' => 'Frist für diese Aufgabe?',
  'Preassign user(s) for this task.' => 'Benutzer für diese Aufgabe vorbelegen.',
  'What to do?' => 'Was ist zu tun?',
    'Assignment' => 'Zuweisung',


);
