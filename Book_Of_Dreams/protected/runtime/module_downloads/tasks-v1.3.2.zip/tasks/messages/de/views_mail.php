<?php
return array (
  'Your Reminder for task {task}' => 'Deine Erinnerung für die Aufgabe {task}',
);
