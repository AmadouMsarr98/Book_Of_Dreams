<?php

return [
    'End Date' => 'Enddatum',
    'End Time' => 'Endzeit',
    'End time must be after start time!' => 'Die Endzeit muss nach der Startzeit liegen!',
    'Public' => 'Öffentlich',
    'Start Date' => 'Startdatum',
    'Start Time' => 'Startzeit',
    'Time Zone' => 'Zeitzone',
];
