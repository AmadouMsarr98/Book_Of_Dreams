<?php
return array (
  '1 Day before' => 'Einen Tag vorher',
  '1 Month before' => 'Einen Monat vorher',
  '1 Week before' => '1 Woche vorher',
  '2 Days before' => 'Zwei Tage vorher',
  '2 Weeks before' => '2 Wochen vorher',
  '3 Weeks before' => '3 Wochen vorher',
  'At least 1 Hour before' => 'Mindestens 1 Stunde vorher',
  'At least 2 Hours before' => 'Mindestens 2 Stunden vorher',
  'Do not remind' => 'Nicht erinnern',
  'Remind Mode' => 'Erinnerungsmodus',
  'Task' => 'Aufgabe',
);
