<?php
return array (
  'Attend' => 'Asistir',
  'Decline' => 'No asistir',
  'Maybe' => 'Tal vez',
  'Participant information:' => 'Información del participante:',
  'Read full description...' => 'Leer descripción completa...',
  'Read full participation info...' => 'Leer información completa de participación...',
);
