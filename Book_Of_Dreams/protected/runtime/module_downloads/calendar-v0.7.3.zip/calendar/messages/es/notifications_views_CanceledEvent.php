<?php

return [
    '{displayName} just added you to event "{contentTitle}".' => '',
    '{displayName} just updated event {contentTitle}.' => '',
    '{displayName} canceled event "{contentTitle}" in space {spaceName}.' => '{displayName} ha cancelado el evento "{contentTitle}" del espacio {spaceName}.',
    '{displayName} canceled event "{contentTitle}".' => '{displayName} ha cancelado el evento "{contentTitle}".',
    '{displayName} just updated event "{contentTitle}" in space {spaceName}.' => '{displayName} ha actualizado el evento "{contentTitle}" del espacio {spaceName}.',
    '{displayName} reopened event "{contentTitle}" in space {spaceName}.' => '{displayName} ha reabierto el evento "{contentTitle}" del espacio {spaceName}.',
    '{displayName} reopened event "{contentTitle}".' => '{displayName} ha reabierto el evento "{contentTitle}".',
];
