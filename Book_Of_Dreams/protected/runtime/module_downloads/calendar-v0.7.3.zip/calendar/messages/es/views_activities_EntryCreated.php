<?php
return array (
  '%displayName% created a new %contentTitle%.' => '%displayName% ha creado un nuevo %contentTitle%.',
);
