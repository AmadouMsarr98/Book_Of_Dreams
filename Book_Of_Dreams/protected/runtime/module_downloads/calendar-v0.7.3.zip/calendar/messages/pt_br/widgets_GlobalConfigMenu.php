<?php
return array (
  'Defaults' => 'Padrões',
  'Event Types' => 'Tipos de Eventos',
  'Other Calendars' => 'Outros calendários',
  'Snippet' => 'Fragmento',
);
