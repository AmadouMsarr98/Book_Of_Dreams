<?php
return array (
  '<strong>Create</strong> new event type' => '<strong>Criar</strong> novo tipo de evento',
  '<strong>Edit</strong> calendar' => '<strong>Editar</strong> calendário',
  '<strong>Edit</strong> event type' => '<strong>Alterar</strong> tipo de evento',
);
