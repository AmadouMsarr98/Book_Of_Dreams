<?php

return [
    '{displayName} just added you to event "{contentTitle}".' => '',
    '{displayName} just updated event {contentTitle}.' => '',
    '{displayName} canceled event "{contentTitle}" in space {spaceName}.' => '{displayName} cancelou o evento "{contentTitle}" no espaço {spaceName}.',
    '{displayName} canceled event "{contentTitle}".' => '{displayName} cancelou o evento "{contentTitle}".',
    '{displayName} just updated event "{contentTitle}" in space {spaceName}.' => '{displayName} acabou de atualizar o evento "{contentTitle}" no espaço {spaceName}.',
    '{displayName} reopened event "{contentTitle}" in space {spaceName}.' => '{displayName} reabriu o evento "{contentTitle}" no espaço {spaceName}.',
    '{displayName} reopened event "{contentTitle}".' => '{displayName} reabriu o evento "{contentTitle}".',
];
