<?php
return array (
  '<strong>Create</strong> event' => '<strong>Utwórz</strong> wydarzenie',
  '<strong>Edit</strong> event' => '<strong>Edytuj</strong> wydarzenie',
  'Basic' => 'Podstawowe',
  'Everybody can participate' => 'Każdy może wziąć udział',
  'Files' => 'Pliki',
  'No participants' => 'Brak biorących udział',
  'Participation' => 'Uczestnictwo',
  'Select event type...' => 'Wybierz typ wydarzenia...',
  'Title' => 'Tytuł',
);
