<?php
return array (
  'Attend' => 'Wezmę udział',
  'Decline' => 'Odrzuć',
  'Maybe' => 'Może',
  'Participant information:' => 'Informacje o uczestnictwie:',
  'Read full description...' => 'Przeczytaj pełen opis...',
  'Read full participation info...' => 'Zobacz pełne informacje o uczestnictwie...',
);
