<?php
return array (
  'Defaults' => 'Domyślne',
  'Event Types' => 'Typy wydarzeń',
  'Other Calendars' => 'Inne kalendarze',
  'Snippet' => 'Panel',
);
