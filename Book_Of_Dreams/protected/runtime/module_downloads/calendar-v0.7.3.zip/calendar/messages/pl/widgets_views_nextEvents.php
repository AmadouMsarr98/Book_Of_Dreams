<?php
return array (
  '<strong>Upcoming</strong> events ' => '<strong>Nadchodzące</strong> wydarzenia',
  'Open Calendar' => 'Otwórz kalendarz',
);
