<?php

return [
    '<strong>Create</strong> event' => '',
    '<strong>Edit</strong> event' => '',
    'Basic' => '',
    'Everybody can participate' => '',
    'Files' => '',
    'No participants' => '',
    'Participation' => '',
    'Select event type...' => '',
    'Title' => '',
];
