<?php

return [
    'Defaults' => '',
    'Event Types' => '',
    'Other Calendars' => '',
    'Snippet' => '',
];
