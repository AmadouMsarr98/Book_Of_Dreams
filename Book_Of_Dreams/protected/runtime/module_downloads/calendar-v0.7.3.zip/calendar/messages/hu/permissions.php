<?php
return array (
  'Allows the user to create new calendar entries' => 'Engedélyezze a felhasználónak, hogy új naptárbejegyzéseket hozhasson létre',
  'Allows the user to edit/delete existing calendar entries' => 'Engedélyezze a felhasználónak, hogy naptárbejegyzéseket szerkeszthessen/törölhessen',
  'Create entry' => 'Bejegyzés létrehozása',
  'Manage entries' => 'Bejegyzések kezelése',
);
