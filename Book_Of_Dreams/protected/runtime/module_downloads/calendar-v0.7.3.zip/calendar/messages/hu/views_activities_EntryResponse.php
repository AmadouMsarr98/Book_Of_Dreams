<?php
return array (
  '%displayName% attends to %contentTitle%.' => '%displayName% részt vesz a következőben: %contentTitle%.',
  '%displayName% maybe attends to %contentTitle%.' => '%displayName% talán részt vesz a következőben: %contentTitle%.',
  '%displayName% not attends to %contentTitle%.' => '%displayName% nem vesz részt a következőben: %contentTitle%.',
);
