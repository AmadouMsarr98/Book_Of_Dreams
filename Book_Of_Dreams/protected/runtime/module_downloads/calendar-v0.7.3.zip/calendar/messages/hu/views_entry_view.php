<?php
return array (
  'Attend' => 'Részt vesz',
  'Decline' => 'Nem vesz részt',
  'Maybe' => 'Talán',
  'Participant information:' => 'Résztvevővel kapcsolatos információk:',
  'Read full description...' => 'Teljes leírás olvasása...',
  'Read full participation info...' => 'A résztvevővel kapcsolatos összes információ olvasása...',
);
