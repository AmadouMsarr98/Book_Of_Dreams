<?php
return array (
  'Defaults' => 'Alapértelmezett',
  'Event Types' => 'Eseménytípusok',
  'Other Calendars' => 'Más naptárak',
  'Snippet' => 'Kódrészlet (snippet)',
);
