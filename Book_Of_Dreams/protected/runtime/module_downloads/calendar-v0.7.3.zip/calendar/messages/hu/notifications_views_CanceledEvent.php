<?php
return array (
  '{displayName} canceled event "{contentTitle}" in space {spaceName}.' => '{displayName} törölte a(z) "{contentTitle}" eseményt a(z) {spaceName} közösségben.',
  '{displayName} canceled event "{contentTitle}".' => '{displayName} törölte a(z) "{contentTitle}" eseményt.',
  '{displayName} just added you to event "{contentTitle}".' => '{displayName} hozzáadott téged a(z) "{contentTitle}" eseményhez.',
  '{displayName} just updated event "{contentTitle}" in space {spaceName}.' => '{displayName} frissítette a(z) "{contentTitle}" eseményt a(z) {spaceName} közösségben.',
  '{displayName} just updated event {contentTitle}.' => '{displayName} frissítette a(z) {contentTitle} eseményt.',
  '{displayName} reopened event "{contentTitle}" in space {spaceName}.' => '{displayName} újranyitotta a(z) "{contentTitle}" eseményt a(z) {spaceName} közösségben.',
  '{displayName} reopened event "{contentTitle}".' => '{displayName} újranyitotta a(z) "{contentTitle}" eseményt',
);
