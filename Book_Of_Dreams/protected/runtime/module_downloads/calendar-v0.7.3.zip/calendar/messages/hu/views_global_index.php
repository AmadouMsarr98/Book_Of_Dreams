<?php
return array (
  '<strong>Filter</strong> events' => 'Esemény <strong>szűrése</strong>',
  '<strong>Select</strong> calendars' => 'Naptárak <strong>kiválasztása</strong>',
  'Followed spaces' => 'Követett közösségek',
  'Followed users' => 'Követett felhasználók',
  'I\'m attending' => 'Részt veszek',
  'My events' => 'Eseményeim',
  'My profile' => 'Profilom',
  'My spaces' => 'Közösségeim',
);
