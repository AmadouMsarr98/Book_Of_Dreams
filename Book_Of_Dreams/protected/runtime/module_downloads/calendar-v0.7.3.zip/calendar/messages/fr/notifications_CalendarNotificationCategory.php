<?php
return array (
  'Calendar' => 'Calendrier',
  'Receive Calendar related Notifications.' => 'Recevoir une notification lorsqu\'on ajoute/modifie/annule des événements liés à mon calendrier.',
);
