<?php
return array (
  '<strong>Create</strong> event' => '<strong>Crea</strong> evento',
  '<strong>Edit</strong> event' => '<strong>Modifica</strong> evento',
  'Basic' => 'Base',
  'Everybody can participate' => 'Ognuno può partecipare',
  'Files' => 'Files',
  'No participants' => 'Nessun partecipante',
  'Participation' => 'Partecipazione',
  'Select event type...' => 'Seleziona il tipo di evento....',
  'Title' => 'Titolo',
);
