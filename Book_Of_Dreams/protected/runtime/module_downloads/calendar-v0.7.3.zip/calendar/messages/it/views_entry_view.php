<?php
return array (
  'Attend' => 'Partecipa',
  'Decline' => 'Rifiuta',
  'Maybe' => 'Forse',
  'Participant information:' => 'Informazioni per i Partecipanti:',
  'Read full description...' => 'Leggi la descrizione completa....',
  'Read full participation info...' => 'Leggi le informazioni sulla partecipazione...',
);
