<?php
return array (
  '%displayName% attends to %contentTitle%.' => '%displayName% partecipa a %contentTitle%.',
  '%displayName% maybe attends to %contentTitle%.' => '%displayName% forse partecipa a %contentTitle%.',
  '%displayName% not attends to %contentTitle%.' => '%displayName% non partecipa a %contentTitle%.',
);
