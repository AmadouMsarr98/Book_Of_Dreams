<?php
return array (
  '%displayName% created a new %contentTitle%.' => '%NamaDisplay% Buat baru %judulkonten%.',
);
