<?php
return array (
  ':count attending' => ':count participă',
  ':count declined' => ':count respingeri',
  ':count maybe' => ':count probabil',
  'Participants:' => 'Participanți:',
);
