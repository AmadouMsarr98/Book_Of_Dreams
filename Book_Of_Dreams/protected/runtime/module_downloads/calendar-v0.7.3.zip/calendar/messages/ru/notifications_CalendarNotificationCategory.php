<?php
return array (
  'Calendar' => 'Календарь',
  'Receive Calendar related Notifications.' => 'Получать оповещения связанные с календарем.',
);
