<?php
return array (
  'Defaults' => 'Standaard instellingen',
  'Event Types' => 'Gebeurtenis-types',
  'Other Calendars' => 'Andere agenda\'s ',
  'Snippet' => 'Codefragment',
);
