<?php
return array (
  '{displayName} canceled event "{contentTitle}" in space {spaceName}.' => '{displayName} annuleerde "{contentTitle}" in ruimte {spaceName}.',
  '{displayName} canceled event "{contentTitle}".' => '{displayName} annuleerde "{contentTitle}".',
  '{displayName} just added you to event "{contentTitle}".' => '{displayName} heeft u zojuist aan "{contentTitle}" toegevoegd.',
  '{displayName} just updated event "{contentTitle}" in space {spaceName}.' => '{displayName} werkte zojuist "{contentTitle}" in ruimte {spaceName} bij.',
  '{displayName} just updated event {contentTitle}.' => '{displayName} heeft {contentTitle} zojuist bijgewerkt.',
  '{displayName} reopened event "{contentTitle}" in space {spaceName}.' => '{displayName} heropende "{contentTitle}" in ruimte {spaceName}.',
  '{displayName} reopened event "{contentTitle}".' => '{displayName} heropende  "{contentTitle}".',
);
