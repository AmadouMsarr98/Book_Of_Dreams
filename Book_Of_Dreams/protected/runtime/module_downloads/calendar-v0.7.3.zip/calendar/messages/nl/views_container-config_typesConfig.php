<?php
return array (
  '<strong>Create</strong> new event type' => '<strong>Maak</strong> nieuw gebeurtenistype',
  '<strong>Edit</strong> calendar' => 'Agenda  <strong>bewerken</ strong>',
  '<strong>Edit</strong> event type' => '<strong>Bewerk</strong> gebeurtenistype',
);
