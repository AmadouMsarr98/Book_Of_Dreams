<?php
return array (
  '<strong>Create</strong> event' => '<strong>Maak</strong> gebeurtenis aan',
  '<strong>Edit</strong> event' => '<strong>Bewerk</strong> gebeurtenis',
  'Basic' => 'Basis',
  'Everybody can participate' => 'Iedereen kan deelnemen',
  'Files' => 'Bestanden',
  'No participants' => 'Geen deelnemers',
  'Participation' => 'Deelnemen',
  'Select event type...' => 'Kies een gebeurtenis-type...',
  'Title' => 'Titel',
);
