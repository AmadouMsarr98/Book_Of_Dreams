<?php
return array (
  ':count attending' => ':count osallistu',
  ':count declined' => ':count ei osallistu',
  ':count maybe' => ':count osallistuu ehkä',
  'Participants:' => 'Osallistujat:',
);
