<?php
return array (
  'Attend' => 'Osallistu',
  'Decline' => 'En osallistu',
  'Maybe' => 'Ehkä osalistun',
  'Participant information:' => 'Tapahtuman tiedot:',
  'Read full description...' => 'Lue täysi kuvaus...',
  'Read full participation info...' => 'Lue tapahtuman tiedot...',
);
