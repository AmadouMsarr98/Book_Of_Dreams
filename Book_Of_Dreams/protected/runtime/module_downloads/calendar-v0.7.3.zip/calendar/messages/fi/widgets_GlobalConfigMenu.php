<?php
return array (
  'Defaults' => 'Oletukset',
  'Event Types' => 'Taphtumatyypit',
  'Other Calendars' => 'Muiden Kalenterit',
  'Snippet' => 'Laatikko',
);
