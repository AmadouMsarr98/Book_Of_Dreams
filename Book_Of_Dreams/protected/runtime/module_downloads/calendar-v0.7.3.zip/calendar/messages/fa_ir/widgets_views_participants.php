<?php
return array (
  ':count attending' => 'شمارش حاضرین count:',
  ':count declined' => ':count شمارش انصراف‌ها:',
  ':count maybe' => 'شمارش احتمالی‌ها count:',
  'Participants:' => 'مشارکت‌کننده‌ها count:',
);
