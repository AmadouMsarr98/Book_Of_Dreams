<?php
return array (
  'Attend' => 'Teilnehmen',
  'Decline' => 'Absagen',
  'Maybe' => 'Vielleicht',
  'Participant information:' => 'Teilnehmer-Information:',
  'Read full description...' => 'Die ganze Beschreibung lesen …',
  'Read full participation info...' => 'Die ganze Teilnehmer-Info lesen …',
);
