<?php
return array (
  'Defaults' => 'Standards',
  'Event Types' => 'Kategorie',
  'Other Calendars' => 'Andere Kalender',
  'Snippet' => 'Widget',
);
