<?php
return array (
  '<strong>Create</strong> new event type' => 'Neue Kategorie <strong>erstellen</strong>',
  '<strong>Edit</strong> calendar' => 'Kalender <strong>bearbeiten</strong>',
  '<strong>Edit</strong> event type' => 'Kategorie <strong>bearbeiten</strong>',
);
