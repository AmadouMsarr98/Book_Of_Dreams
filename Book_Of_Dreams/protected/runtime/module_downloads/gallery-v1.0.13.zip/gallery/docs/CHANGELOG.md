Changelog
=========

1.0.13 - June 15, 2019
---------------------
- Enh.: Updated translations
- Enh.: Improved docs


1.0.12 - August 29, 2018
---------------------
- Fix: WriteAccess not used as ManagePermission


1.0.11 - August 29, 2018
---------------------
- Fix: Gallery setting menu item visible for non space admins


1.0.10 - July 16, 2018
---------------------
- Fix: added 'jpeg' to allowed extensions
- Enh: Added media icon


1.0.9 - July 2, 2018
---------------------
- Fix: Error when baseFile not exists
- Fix: PHP 7.2 compatibility issues


1.0.8 - December 20, 2017
---------------------
- Fix: Guest access write check
- Enh: Updated translations

