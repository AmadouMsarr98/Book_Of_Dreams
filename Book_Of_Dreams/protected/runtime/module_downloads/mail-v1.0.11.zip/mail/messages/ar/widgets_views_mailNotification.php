<?php
return array (
  'Messages' => 'الرسائل',
  'New message' => 'رسالة جديدة',
  'Show all messages' => 'عرض كل الرسائل',
);
