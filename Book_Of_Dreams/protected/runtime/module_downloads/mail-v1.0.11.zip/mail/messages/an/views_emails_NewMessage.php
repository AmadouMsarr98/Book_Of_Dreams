<?php
return array (
  '<strong>New</strong> message' => '<strong>Nuevo</strong> mensache',
  'Reply now' => '',
  'sent you a new message:' => '',
);
