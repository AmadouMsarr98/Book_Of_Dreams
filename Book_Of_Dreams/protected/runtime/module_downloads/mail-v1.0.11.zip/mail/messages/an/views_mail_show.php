<?php

return [
    '<strong>Confirm</strong> deleting conversation' => '',
    '<strong>Confirm</strong> leaving conversation' => '',
    '<strong>Confirm</strong> message deletion' => '',
    'Add user' => '',
    'Delete conversation' => '',
    'Do you really want to delete this conversation?' => '',
    'Do you really want to delete this message?' => '',
    'Do you really want to leave this conversation?' => '',
    'Leave' => '',
    'Leave conversation' => '',
    'Cancel' => 'Cancelar',
    'Delete' => 'Eliminar',
    'Send' => 'Ninviar',
    'There are no messages yet.' => 'Encara no i hai mensaches',
];
