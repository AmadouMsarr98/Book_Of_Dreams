<?php
return array (
  'Groups' => 'Grups',
  'Members' => 'Membres',
  'Spaces' => 'Espais',
  'User Posts' => 'Publicacions de membres',
);
