<?php

return [
    'User {name} is already participating!' => '',
    'You are not allowed to send user {name} is already!' => '',
    'You cannot send a email to yourself!' => '',
    'Recipient' => 'Destinatari',
];
