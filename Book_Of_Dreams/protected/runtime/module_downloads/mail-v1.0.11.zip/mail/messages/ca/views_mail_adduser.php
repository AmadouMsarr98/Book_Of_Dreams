<?php

return [
    'Add more participants to your conversation...' => 'Afegeix més participants a la conversa...',
];
