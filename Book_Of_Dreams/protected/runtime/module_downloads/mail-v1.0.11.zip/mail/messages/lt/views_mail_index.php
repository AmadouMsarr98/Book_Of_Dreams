<?php

return [
    'Conversations' => '',
    'New' => 'Naujas',
    'There are no messages yet.' => 'Kol kas nėra žinučių.',
];
