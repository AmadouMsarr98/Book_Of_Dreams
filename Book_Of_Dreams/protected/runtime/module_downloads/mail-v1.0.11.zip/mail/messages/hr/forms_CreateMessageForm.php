<?php
return array (
  'Message' => 'Poruka',
  'Recipient' => 'Primatelj',
  'Subject' => 'Predmet',
  'You cannot send a email to yourself!' => 'Ne možete poslati email sami sebi!',
);
