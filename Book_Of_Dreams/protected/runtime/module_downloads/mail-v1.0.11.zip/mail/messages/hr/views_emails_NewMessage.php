<?php
return array (
  '<strong>New</strong> message' => '<strong>Nova</strong> poruka',
  'Reply now' => 'Odgovori sada',
  'sent you a new message:' => 'poslao vam je novu poruku:',
);
