<?php

return [
    'Add recipients' => 'Dodaj primatelje',
    'New message' => 'Nova poruka',
    'Send' => 'Pošalji',
];
