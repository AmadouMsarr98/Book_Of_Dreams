<?php

return [
    'Edit message entry' => 'Edytuj treść wiadomości',
];
