<?php
return array (
  'sent you a new message in' => 'wysłał(a) do ciebie nową wiadomość w ',
);
