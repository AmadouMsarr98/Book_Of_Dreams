<?php
return array (
  '<strong>New</strong> message' => '<strong>Nowa</strong> wiadomość ',
  'Reply now' => 'Odpowiedz teraz ',
  'sent you a new message:' => 'wysłał(a) do ciebie nową wiadomość: ',
);
