<?php
return array (
  'New message in discussion from %displayName%' => 'Nowa wiadomość w dyskusji od %displayName% ',
);
