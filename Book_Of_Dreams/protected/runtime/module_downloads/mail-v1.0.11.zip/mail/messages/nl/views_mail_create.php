<?php

return [
    'Add recipients' => 'Ontvangers toevoegen',
    'New message' => 'Nieuwe bericht',
    'Send' => 'Verstuur',
];
