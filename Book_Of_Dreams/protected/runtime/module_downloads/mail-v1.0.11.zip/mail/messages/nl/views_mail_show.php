<?php
return array (
  '<strong>Confirm</strong> deleting conversation' => '<strong>Gesprek</strong> verwijderen',
  '<strong>Confirm</strong> leaving conversation' => '<strong>Gesprek</strong> verlaten',
  '<strong>Confirm</strong> message deletion' => '<strong>Bericht</strong> verwijderen',
  'Add user' => 'Gebruiker toevoegen',
  'Cancel' => 'Annuleren',
  'Delete' => 'Verwijder',
  'Delete conversation' => 'Verwijder gesprek',
  'Do you really want to delete this conversation?' => 'Wilt u dit gesprek echt verwijderen?',
  'Do you really want to delete this message?' => 'Wilt u dit bericht echt verwijderen?',
  'Do you really want to leave this conversation?' => 'Wilt u dit gesprek echt verlaten?',
  'Leave' => 'Verlaat',
  'Leave conversation' => 'Verlaat gesprek',
  'Send' => 'Versturen',
  'There are no messages yet.' => 'Er zijn nog geen berichten.',
);
