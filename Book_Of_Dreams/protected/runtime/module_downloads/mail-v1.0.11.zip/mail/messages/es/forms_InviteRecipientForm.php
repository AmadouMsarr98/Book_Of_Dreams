<?php

return [
    'User {name} is already participating!' => '',
    'You are not allowed to send user {name} is already!' => '',
    'Recipient' => 'Receptor',
    'You cannot send a email to yourself!' => 'No te puedes enviar mensajes tu mismo!',
];
