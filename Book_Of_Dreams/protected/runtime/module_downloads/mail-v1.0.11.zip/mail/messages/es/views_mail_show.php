<?php

return [
    'Delete conversation' => '',
    'Leave conversation' => '',
    '<strong>Confirm</strong> deleting conversation' => '<strong>Confirmar</strong> eliminación de la conversación',
    '<strong>Confirm</strong> leaving conversation' => '<strong>Confirmar</strong> salida de la conversación',
    '<strong>Confirm</strong> message deletion' => '<strong>Confirmar</strong> eliminación del mensaje',
    'Add user' => 'Añadir usuario',
    'Cancel' => 'Cancelar',
    'Delete' => 'Eliminar',
    'Do you really want to delete this conversation?' => '¿Seguro que quieres eliminar esta conversación?',
    'Do you really want to delete this message?' => '¿Seguro que quieres eliminar este mensaje?',
    'Do you really want to leave this conversation?' => '¿Seguro que quieres abandonar esta conversación?',
    'Leave' => 'Abandonar',
    'Send' => 'Enviar',
    'There are no messages yet.' => 'No hay mensajes aún.',
];
