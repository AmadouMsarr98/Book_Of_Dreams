<?php
return array (
  'New message' => 'Nouveau message',
  'Send message' => 'Envoyer un message',
);
