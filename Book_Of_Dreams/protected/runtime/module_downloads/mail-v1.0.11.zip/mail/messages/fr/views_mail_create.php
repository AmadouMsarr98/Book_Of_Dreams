<?php

return [
    'Add recipients' => 'Ajouter des destinataires',
    'New message' => 'Nouveau message',
    'Send' => 'Envoyer',
];
