<?php
return array (
  'Messages' => 'Съобщения',
  'New message' => '',
  'Show all messages' => '',
);
