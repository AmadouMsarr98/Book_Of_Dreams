<?php

return [
    'Delete conversation' => '',
    'Leave conversation' => '',
    '<strong>Confirm</strong> deleting conversation' => '<strong>Smazání</strong> konverzace',
    '<strong>Confirm</strong> leaving conversation' => '<strong>Opuštění</strong> konverzace',
    '<strong>Confirm</strong> message deletion' => '<strong>Smazání</strong> zprávy',
    'Add user' => 'Přidat uživatele',
    'Cancel' => 'Zrušit',
    'Delete' => 'Smazat',
    'Do you really want to delete this conversation?' => 'Opravdu chcete smazat tuto konverzaci?',
    'Do you really want to delete this message?' => 'Opravdu chcete smazat tuto zprávu?',
    'Do you really want to leave this conversation?' => 'Opravdu chcete opustit tuto konverzaci?',
    'Leave' => 'Opustit',
    'Send' => 'Poslat',
    'There are no messages yet.' => 'Zatím zde nejsou žádné zprávy.',
];
