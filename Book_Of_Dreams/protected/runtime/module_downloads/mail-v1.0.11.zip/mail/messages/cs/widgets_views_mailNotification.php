<?php
return array (
  'Messages' => 'Zprávy',
  'New message' => 'Nová zpráva',
  'Show all messages' => 'Zobrazit všechny zprávy',
);
