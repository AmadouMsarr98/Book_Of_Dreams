<?php

return [
    'Edit message entry' => 'Změnit obsah zprávy',
];
