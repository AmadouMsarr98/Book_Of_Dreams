<?php
return array (
  'New message from {senderName}' => 'Nová zpráva od uživatele {senderName}',
  'and {counter} other users' => 'a dalších {counter} uživatelů',
);
