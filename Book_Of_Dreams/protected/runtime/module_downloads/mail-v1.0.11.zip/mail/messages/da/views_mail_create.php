<?php

return [
    'Add recipients' => 'Tilføjet modtagere',
    'New message' => 'Ny besked',
    'Send' => 'Send',
];
