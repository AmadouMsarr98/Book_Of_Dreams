<?php

return [
    'Edit message entry' => 'Rediger besked',
];
