<?php
return array (
  'New message in discussion from %displayName%' => 'Ny besked i samtalen med %displayName%',
);
