<?php

return [
    'sent you a new message in' => '',
];
