<?php

return [
    'New message' => '',
    'Send message' => '',
];
