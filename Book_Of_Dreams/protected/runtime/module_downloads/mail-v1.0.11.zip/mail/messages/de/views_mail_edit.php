<?php

return [
    'Edit message entry' => 'Nachricht bearbeiten',
];
