<?php
return array (
  'There are no messages yet.' => 'Es sind noch keine Nachrichten vorhanden.',
);
