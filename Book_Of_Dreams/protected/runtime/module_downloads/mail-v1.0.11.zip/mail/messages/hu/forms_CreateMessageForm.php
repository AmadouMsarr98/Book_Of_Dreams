<?php
return array (
  'Message' => 'Üzenet',
  'Recipient' => 'Címzett',
  'Subject' => 'Tárgy',
  'You cannot send a email to yourself!' => 'Magadnak nem küldhetsz üzenetet!',
);
