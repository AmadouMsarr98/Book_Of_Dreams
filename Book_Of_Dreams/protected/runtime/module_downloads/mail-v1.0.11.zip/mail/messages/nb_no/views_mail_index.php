<?php

return [
    'Conversations' => 'Samtaler',
    'New' => 'Ny',
    'There are no messages yet.' => 'Det er ingen meldinger her enda.',
];
