<?php

return [
    'Edit message entry' => 'Labot ziņas ierakstu',
];
