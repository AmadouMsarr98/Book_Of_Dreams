<?php

return [
    'Conversations' => '',
    'New' => '新規',
    'There are no messages yet.' => 'まだ何もメッセージはありません。',
];
