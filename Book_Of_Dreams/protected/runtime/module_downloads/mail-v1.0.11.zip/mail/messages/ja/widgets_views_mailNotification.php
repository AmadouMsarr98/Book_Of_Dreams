<?php
return array (
  'Messages' => 'メッセージ',
  'New message' => '新規メッセージ',
  'Show all messages' => '全てのメッセージを表示',
);
