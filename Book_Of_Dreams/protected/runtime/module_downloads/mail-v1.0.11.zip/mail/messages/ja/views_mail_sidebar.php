<?php
return array (
  'Groups' => 'グループ',
  'Members' => 'メンバー',
  'Spaces' => 'スペース',
  'User Posts' => 'ユーザー投稿',
);
