<?php

return [
    'Conversations' => 'Keskustelut',
    'New' => 'Uusi',
    'There are no messages yet.' => 'Viestejä ei ole vielä.',
];
