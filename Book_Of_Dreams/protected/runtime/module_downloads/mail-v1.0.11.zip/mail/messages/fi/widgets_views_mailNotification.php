<?php
return array (
  'Messages' => 'Viestit',
  'New message' => 'Uusi viesti',
  'Show all messages' => 'Näytä kaikki viestit',
);
