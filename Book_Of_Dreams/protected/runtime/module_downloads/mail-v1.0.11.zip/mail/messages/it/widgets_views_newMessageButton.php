<?php
return array (
  'New message' => 'Nuovo messaggio',
  'Send message' => 'Invia messaggio',
);
