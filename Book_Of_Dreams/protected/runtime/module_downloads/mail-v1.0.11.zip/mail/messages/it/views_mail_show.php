<?php
return array (
  '<strong>Confirm</strong> deleting conversation' => '<strong>Confermi</strong> l\'eliminazione della conversazione?',
  '<strong>Confirm</strong> leaving conversation' => '<strong>Confermi</strong> di lasciare la conversazione?',
  '<strong>Confirm</strong> message deletion' => '<strong>Confermi</strong> l\'eliminazione del messaggio?',
  'Add user' => 'Aggiungi utente',
  'Cancel' => 'Annulla',
  'Delete' => 'Cancella',
  'Delete conversation' => 'Cancella conversazione',
  'Do you really want to delete this conversation?' => 'Vuoi eliminare questa conversazione?',
  'Do you really want to delete this message?' => 'Vuoi eliminare questo messaggio?',
  'Do you really want to leave this conversation?' => 'Vuoi abbandonare questa conversazione?',
  'Leave' => 'Lascia',
  'Leave conversation' => 'Abbamdona conversazione',
  'Send' => 'Invia',
  'There are no messages yet.' => 'Non ci sono messaggi.',
);
